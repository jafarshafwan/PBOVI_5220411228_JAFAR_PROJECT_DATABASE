from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from docx import Document

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/5220411228'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'test-jafar'

db = SQLAlchemy(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    price = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_product')
def add_product():
    return render_template('add_product.html')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/list_product')
def list_product():
    return render_template('list_product.html')

@app.route('/products', methods=['GET', 'POST'])
def products():
    if request.method == 'GET':
        products = Product.query.all()
        product_list = [{'id': product.id, 'name': product.name, 'price': product.price, 'quantity': product.quantity} for product in products]
        return jsonify({'products': product_list})
    elif request.method == 'POST':
        if 'username' not in session:
            return jsonify({'error': 'User not authenticated'}), 401
        data = request.get_json()
        new_product = Product(name=data['name'], price=data['price'], quantity=data['quantity'])
        db.session.add(new_product)
        db.session.commit()
        products = Product.query.all()
        products_list = [{'id': product.id, 'name': product.name, 'price': product.price, 'quantity': product.quantity} for product in products]
        return jsonify({'message': 'Product created successfully', 'product': {'id': new_product.id, 'name': new_product.name, 'price': new_product.price, 'quantity': new_product.quantity}, 'products': products_list}), 201

@app.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    product = Product.query.get(product_id)
    if product:
        data = request.get_json()
        product.name = data.get('name', product.name)
        product.price = data.get('price', product.price)
        product.quantity = data.get('quantity', product.quantity)
        db.session.commit()
        return jsonify({'message': 'Product updated successfully', 'product': {'id': product.id, 'name': product.name, 'price': product.price, 'quantity': product.quantity}})
    else:
        return jsonify({'message': 'Product not found'}), 404

@app.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    product = Product.query.get(product_id)
    if product:
        db.session.delete(product)
        db.session.commit()
        return jsonify({'message': 'Product deleted successfully'}), 200
    else:
        return jsonify({'message': 'Product not found'}), 404

@app.route('/products/<int:product_id>/edit', methods=['GET'])
def edit_product_form(product_id):
    product = Product.query.get(product_id)
    if product:
        return render_template('edit_product.html', product=product)
    else:
        return jsonify({'message': 'Product not found'}), 404

@app.route('/login-api', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user = User.query.filter_by(username=username, password=password).first()
    if user:
        session['user_id'] = user.id
        session['username'] = user.username
        return jsonify({'message': 'Login successful'})
    else:
        return jsonify({'message': 'Login failed. Invalid credentials'}), 401

@app.route('/logout', methods=['GET'])
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/check-auth', methods=['GET'])
def check_authentication():
    if 'user_id' in session:
        return jsonify({'authenticated': True, 'username': session['username']})
    else:
        return jsonify({'authenticated': False})

def create_word_document():
    document = Document()
    document.add_heading('Documentation - PBO Program', 0)

    document.add_heading('Database Structure', level=1)
    document.add_paragraph('Database Name: 5220411228')

    document.add_heading('Product Table', level=2)
    document.add_paragraph('Columns: id, name, price, quantity')

    document.add_heading('User Table', level=2)
    document.add_paragraph('Columns: id, username, password')

    document.add_heading('Program Code', level=1)
    with open(__file__, 'r') as file:
        code = file.read()
        document.add_paragraph(code)

    document.add_heading('Program Execution Results', level=1)
    # Add screenshots or descriptions of insert, update, delete, select operations

    document.save('PBO_Program_Documentation.docx')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_word_document()
    app.run(debug=True)